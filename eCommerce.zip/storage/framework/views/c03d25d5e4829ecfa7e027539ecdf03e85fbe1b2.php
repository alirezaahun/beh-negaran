<?php if( count($errors) > 0 ): ?>

    <div class="alert alert-danger">

        <ul class="mb-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="alert alert-text"> <?php echo e($error); ?> </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    </div>

<?php endif; ?>
<?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/sections/errors.blade.php ENDPATH**/ ?>