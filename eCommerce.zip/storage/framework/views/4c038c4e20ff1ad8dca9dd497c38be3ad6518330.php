

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="mb-4">

            <h5 class="font-weight-bold">ایجاد برند</h5>

            <hr>

            <?php echo $__env->make('admin.sections.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form action="<?php echo e(route('admin.brands.update' , ['brand' => $brand->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

               <div class="form-row">

                <div class="form-group col-md-3">

                    <label for="name">نام</label>
                    <input class="form-control" value="<?php echo e($brand->name); ?>" type="text" name="name" id="name">

                </div>

                <div class="form-group col-md-3">

                    <label for="is_active">وضعیت</label>
                    <select class="form-control" name="is_active" id="is_active">

                        <option value="1" <?php echo e($brand->getRawOriginal('is_active') ? 'selected':''); ?>>فعال</option>
                        <option value="0" <?php echo e($brand->getRawOriginal('is_active') ? 'selected' : ''); ?>>غیرفعال</option>

                    </select>

                </div>
               </div>

                <button type="submit" class="btn btn-outline-primary mt-5">ویرایش</button>
                <a href="<?php echo e(route('admin.brands.index')); ?>" class="btn mt-5 mr-3 btn-dark"> بازگشت </a>

            </form>


        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\beh_negaran_eCommerce\eCommerce\resources\views/admin/brands/edit.blade.php ENDPATH**/ ?>