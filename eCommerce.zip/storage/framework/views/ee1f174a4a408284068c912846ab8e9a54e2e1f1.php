
<!DOCTYPE html>
<html lang="fa" class="no-js">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?php echo $__env->yieldContent('title'); ?></title>

  <!-- Custom styles for this template-->
  <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">

</head>

<body>


    <?php echo $__env->make('home.sections.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('home.sections.mobile_off_canvas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('content'); ?>

  <?php echo $__env->make('home.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <script src="<?php echo e(asset('js/home/jquery-1.12.4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/home/plugins.js')); ?>"></script>
  <script src="<?php echo e(asset('js/home.js')); ?>"></script>


  <?php echo $__env->yieldContent('scripts'); ?>

  <?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/home/layouts/master.blade.php ENDPATH**/ ?>