

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="d-flex justify-content-between mb-4">

            <h5 class="font-weight-bold">لیست برندها (<?php echo e($categories->total()); ?>)</h5>

            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.categories.create')); ?>">

                <li class="fa fa-plus"></li>

                ایجاد دسته بندی

            </a>


        </div>

        <table class="table table-bordered table-striped text-center">

            <thead>

                <tr>

                    <th>
                        #
                    </th>
                    <th>
                        نام
                    </th>
                    <th>
                        نام انگلیسی
                    </th>
                    <th>
                        والد
                    </th>
                    <th>
                        وضعیت
                    </th>
                    <th>
                        عملیات
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th>
                    <?php echo e($categories->firstItem() + $key); ?>

                    </th>

                    <th>
                        <?php echo e($category->name); ?>

                    </th>

                    <th>
                        <?php echo e($category->slug); ?>

                    </th>

                    <th>
                        <?php if($category->parent_id == 0): ?>

                        <?php echo e($category->name); ?>


                        <?php else: ?>

                        <?php echo e($category->parent->name); ?>


                        <?php endif; ?>

                    </th>

                    <th>
                     <span class="<?php echo e($category->getRawOriginal('is_active') ? 'text-success':'text-danger'); ?>">   <?php echo e($category->is_active); ?> </span>
                    </th>

                    <th>
                        <a href="<?php echo e(route('admin.categories.show' , ['category' => $category->id])); ?>" class="btn btn-outline-success">نمایش</a>
                        <a href="<?php echo e(route('admin.categories.edit' , ['category' => $category->id])); ?>" class="btn btn-outline-info">ویرایش</a>
                    </th>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\beh_negaran_eCommerce\eCommerce\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>