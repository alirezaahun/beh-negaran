<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="mb-4">

            <h5 class="font-weight-bold">محصول : <?php echo e($product->name); ?></h5>

            <hr>


               <div class="row">

                <div class="form-group col-md-3">

                    <label for="name">نام</label>
                    <input class="form-control" type="text" value="<?php echo e($product->name); ?>" disabled>

                </div>

                <div class="form-group col-md-3">

                    <label for="name">نام برند</label>
                    <input class="form-control" type="text" value="<?php echo e($product->brand->name); ?>" disabled>

                </div>

                <div class="form-group col-md-3">

                    <label for="name">نام دسته بندی</label>
                    <input class="form-control" type="text" value="<?php echo e($product->category->name); ?>" disabled>

                </div>


                <div class="form-group col-md-3">

                    <label for="name">وضعیت</label>
                    <input class="form-control" type="text" value="<?php echo e($product->is_active); ?>" disabled>

                </div>

                <div class="form-group col-md-3">

                    <label for="name">تاریخ ایجاد محصول</label>
                    <input class="form-control" type="text" value="<?php echo e(verta($product->created_at)); ?>" disabled>

                </div>

                <div class="form-group col-md-12">

                    <label for="name">توضیحات</label>
                    <textarea class="form-control" type="text" disabled><?php echo e($product->description); ?></textarea>

                </div>

                <div class="col-md-12">

                    <hr>

                    <p>هزینه ارسال</p>

                </div>

                <div class="form-group col-md-3">

                    <label for="name">هزینه ارسال</label>
                    <input class="form-control" type="text" value="<?php echo e($product->delivery_amount); ?>" disabled>

                </div>

                <div class="form-group col-md-3">

                    <label for="name">هزینه ارسال به ازای هر محصول</label>
                    <input class="form-control" type="text" value="<?php echo e($product->delivery_amount_per_product); ?>" disabled>

                </div>

                <div class="col-md-12">

                    <hr>

                    <p>ویژگی ها</p>

                </div>

                <?php $__currentLoopData = $productAttribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productAttributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="form-group col-md-3">

                    <label for="name"><?php echo e($productAttributes->attribute->name); ?></label>
                    <input class="form-control" type="text" value="<?php echo e($productAttributes->value); ?>" disabled>

                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </div>

               <?php $__currentLoopData = $productVariations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <div class="col-md-12">

                    <hr>

                    <div class="d-flex">

                        <p class="mb-0"> قیمت و موجودی برای متغیر (<?php echo e($variation->value); ?>) </p>

                        <p class="mb-0 mr-3">

                            <button class="btn btn-sm btn-primary" type="button" data-toggle="collapse" data-target="#collapse-<?php echo e($variation->id); ?>">

                                نمایش

                            </button>

                        </p>

                    </div>

               </div>

               <div class="col-md-12">

                    <div class="collapse mt-2" id="collapse-<?php echo e($variation->id); ?>">


                        <div class="card card-body">

                            <div class="row">


                                <div class="form-group col-md-3">

                                    <label for="name">قیمت</label>
                                    <input class="form-control" type="text" value="<?php echo e($variation->price); ?>" disabled>

                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">تعداد</label>
                                    <input class="form-control" type="text" value="<?php echo e($variation->quantity); ?>" disabled>

                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">شناسه انبار</label>
                                    <input class="form-control" type="text" value="<?php echo e($variation->sku); ?>" disabled>

                                </div>

                                <div class="col-md-12">

                                    <hr>

                                    <p>حراجی</p>

                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">قیمت تخفیف</label>
                                    <input class="form-control" type="text" value="<?php echo e($variation->sale_price); ?>" disabled>

                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">تاریخ شروع تخفیف</label>
                                    <input class="form-control" type="text" value="<?php echo e($variation->date_on_sale_from == null ? null:verta($variation->date_on_sale_from)); ?>" disabled>

                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">تاریخ پایان تخفیف</label>
                                    <input class="form-control" type="text" value="<?php echo e($variation->date_on_sale_to == null ? null:verta($variation->date_on_sale_to)); ?>" disabled>

                                </div>


                            </div>

                        </div>

                    </div>

               </div>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


               <div class="col-md-12">

                <hr>

                <p>تصویر اصلی محصول</p>

            </div>


               <div class="col-md-3">

                    <div class="card">

                        <img src="<?php echo e(url(env('PRODUCT_IMAGE_UPLOAD_PATH') . $product->primary_image)); ?>" alt="<?php echo e($product->name); ?>" class="card-img-top">

                    </div>

               </div>


               <div class="col-md-12">

                <hr>

                <p>سایر تصاویر محصول</p>

            </div>

            <div class="row">
            <?php $__currentLoopData = $productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <div class="col-md-3">

                    <div class="card">

                        <img src="<?php echo e(url(env('PRODUCT_IMAGE_UPLOAD_PATH') . $image->image)); ?>" alt="<?php echo e($product->name); ?>" class="card-img-top">

                    </div>

               </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


          </div>



                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn mt-5 mr-3 btn-dark"> بازگشت </a>



        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/products/show.blade.php ENDPATH**/ ?>