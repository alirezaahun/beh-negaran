<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="d-flex justify-content-between mb-4">

            <h5 class="font-weight-bold">لیست ویژگی ها (<?php echo e($attribute->total()); ?>)</h5>

            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.attributes.create')); ?>">

                <li class="fa fa-plus"></li>

                ایجاد ویژگی

            </a>


        </div>

        <table class="table table-bordered table-striped text-center">

            <thead>

                <tr>

                    <th>
                        #
                    </th>
                    <th>
                        نام
                    </th>

                    <th>
                        قیمت
                    </th>

                    <th>
                        اولویت
                    </th>

                    <th>
                        عملیات
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__currentLoopData = $attribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th>
                    <?php echo e($attribute->firstItem() + $key); ?>

                    </th>

                    <th>
                        <?php echo e($attributes->name); ?>

                    </th>
                    <th>
                        <?php echo e($attributes->price); ?>

                    </th>
                    <th>
                        <?php echo e($attributes->priority); ?>

                    </th>


                    <th>
                        <a href="<?php echo e(route('admin.attributes.edit' , ['attribute' => $attributes->id])); ?>" class="btn btn-outline-info">ویرایش</a>
                    </th>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\beh_negaran_eCommerce\eCommerce\resources\views/admin/attributes/index.blade.php ENDPATH**/ ?>