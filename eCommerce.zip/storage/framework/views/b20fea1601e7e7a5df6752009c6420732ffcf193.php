<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="d-flex justify-content-between mb-4">

            <h5 class="font-weight-bold">لیست برندها (<?php echo e($brand->total()); ?>)</h5>

            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.brands.create')); ?>">

                <li class="fa fa-plus"></li>

                ایجاد برند

            </a>


        </div>

        <table class="table table-bordered table-striped text-center">

            <thead>

                <tr>

                    <th>
                        #
                    </th>
                    <th>
                        نام
                    </th>
                    <th>
                        وضعیت
                    </th>
                    <th>
                        عملیات
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th>
                    <?php echo e($brand->firstItem() + $key); ?>

                    </th>

                    <th>
                        <?php echo e($brands->name); ?>

                    </th>

                    <th>
                     <span class="<?php echo e($brands->getRawOriginal('is_active') ? 'text-success':'text-danger'); ?>">   <?php echo e($brands->is_active); ?> </span>
                    </th>

                    <th>
                        <a href="<?php echo e(route('admin.brands.show' , ['brand' => $brands->id])); ?>" class="btn btn-outline-success">نمایش</a>
                        <a href="<?php echo e(route('admin.brands.edit' , ['brand' => $brands->id])); ?>" class="btn btn-outline-info">ویرایش</a>
                    </th>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/brands/index.blade.php ENDPATH**/ ?>