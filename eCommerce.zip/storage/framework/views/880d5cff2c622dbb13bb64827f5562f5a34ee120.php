<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="d-flex justify-content-between mb-4">

            <h5 class="font-weight-bold">لیست محصولات (<?php echo e($products->total()); ?>)</h5>

            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.products.create')); ?>">

                <li class="fa fa-plus"></li>

                ایجاد محصول

            </a>


        </div>

        <table class="table table-bordered table-striped text-center">

            <thead>

                <tr>

                    <th>
                        #
                    </th>
                    <th>
                        نام محصول
                    </th>
                    <th>
                        برند محصول
                    </th>
                    <th>
                        دسته بندی محصول
                    </th>
                    <th>
                        وضعیت
                    </th>
                    <th>
                        عملیات
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th>
                    <?php echo e($products->firstItem() + $key); ?>

                    </th>

                    <th>
                        <a href="<?php echo e(Route('admin.products.show', ['product' => $product->id])); ?>">

                            <?php echo e($product->name); ?>


                        </a>
                    </th>

                    <th>
                        <a href="<?php echo e(Route('admin.brands.show' , ['brand' => $product->brand->id])); ?>">

                            <?php echo e($product->brand->name); ?>


                        </a>
                    </th>

                    <th>
                        <a href="<?php echo e(Route('admin.categories.show' , ['category' => $product->category->id])); ?>">

                            <?php echo e($product->category->name); ?>


                        </a>
                    </th>

                    <th>
                        <span class="<?php echo e($product->getRawOriginal('is_active') ? 'text-success':'text-danger'); ?>">   <?php echo e($product->is_active); ?> </span>

                    </th>

                    <th>

                        <div class="btn-group">

                        <button class="btn btn-sm btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                            عملیات

                        </button>

                        <div class="dropdown-menu">

                            <a href="<?php echo e(route('admin.products.edit', ['product'=> $product->id])); ?>" class="dropdown-item text-right">ویرایش محصول</a>

                            <a href="<?php echo e(route('admin.product.image.edit', ['product'=> $product->id])); ?>" class="dropdown-item text-right">ویرایش تصویر</a>

                            <a href="<?php echo e(route('admin.product.EditCategory.edit', ['product'=> $product->id])); ?>" class="dropdown-item text-right">ویرایش دسته بندی و ویژگی</a>

                        </div>

                    </div>

                    </th>


                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/products/index.blade.php ENDPATH**/ ?>