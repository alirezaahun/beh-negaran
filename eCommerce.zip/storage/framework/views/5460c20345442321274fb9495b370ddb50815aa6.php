<?php $__env->startSection('content'); ?>

<?php $__env->startSection('scripts'); ?>

<script>

$("#czContainer").czMore();

$("#brandSelect").selectpicker({
    'title': 'انتخاب برند'
});

$("#is_active").selectpicker({
    'title': 'وضعیت'
});

$("#tagSelect").selectpicker({
    'title': 'انتخاب تگ'
});

let variations = <?php echo json_encode($productVariations, 15, 512) ?>;

variations.forEach(variation => {

    $(`#variationDateOnSaleFrom-${variation.id}`).MdPersianDateTimePicker({
    targetTextSelector: `#variationInputDateOnSaleFrom-${variation.id}`,
    englishNumber: true,
    enableTimePicker: true,
    textFormat: 'yyyy-MM-dd HH:mm:ss',
});

$(`#variationDateOnSaleTo-${variation.id}`).MdPersianDateTimePicker({
    targetTextSelector: `#variationInputDateOnSaleTo-${variation.id}`,
    englishNumber: true,
    enableTimePicker: true,
    textFormat: 'yyyy-MM-dd HH:mm:ss',

});

});

$("#variationDateOnSaleFrom").MdPersianDateTimePicker({
  targetTextSelector: '#variationInputDateOnSaleFrom'});

</script>

<?php $__env->stopSection(); ?>



<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="mb-4">

            <h5 class="font-weight-bold">ویراش محصول <?php echo e($product->name); ?></h5>

            <hr>

            <?php echo $__env->make('admin.sections.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form action="<?php echo e(route('admin.products.update' , ['product' => $product->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

               <div class="form-row">

                <div class="form-group col-md-3">

                    <label for="name">نام</label>
                    <input class="form-control" value="<?php echo e($product->name); ?>" type="text" name="name" id="name">

                </div>


                <div class="form-group col-md-3">

                    <label for="parent_id">انتخاب برند</label>
                    <select id="brandSelect" data-live-search="true" name="brand_id"class="form-control">

                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brand->id); ?>" <?php echo e($brand->id == $product->brand->id ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>

                </div>


                <div class="form-group col-md-3">

                    <label for="is_active">وضعیت</label>
                    <select class="form-control" name="is_active" id="is_active">

                        <option value="1" <?php echo e($product->getRawOriginal('is_active') ? 'selected' : ''); ?>>فعال</option>
                        <option value="0" <?php echo e($product->getRawOriginal('is_active') ? '' : 'selected'); ?>>غیرفعال</option>

                    </select>

                </div>


                <div class="form-group col-md-3">

                    <label for="tag_ids">انتخاب تگ</label>
                    <select id="tagSelect" multiple data-live-search="true" name="tag_ids[]" class="form-control">

                        <?php
                            $getTags = $product->tags()->pluck('id')->toArray()
                        ?>

                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tag->id); ?>" <?php echo e(in_array($tag->id , $getTags) ? 'selected' : ''); ?>><?php echo e($tag->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>

                </div>


                <div class="form-group col-md-12">

                    <label for="name">توضیحات</label>
                    <textarea class="form-control" rows="4" type="text" name="description" id="description"><?php echo e($product->description); ?></textarea>

                </div>

                <div class="col-md-12">

                    <hr>

                    <p>هزینه ارسال</p>

                </div>

                <div class="form-group col-md-3">

                    <label for="name">هزینه ارسال</label>
                    <input class="form-control" type="text" name="delivery_amount" value="<?php echo e($product->delivery_amount); ?>" >

                </div>

                <div class="form-group col-md-3">

                    <label for="name">هزینه ارسال به ازای هر محصول</label>
                    <input class="form-control" name="delivery_amount_per_product" type="text" value="<?php echo e($product->delivery_amount_per_product); ?>" >

                </div>

                <div class="col-md-12">

                    <hr>

                    <p>ویژگی ها</p>

                </div>

                <?php $__currentLoopData = $productAttribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productAttributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="form-group col-md-3">

                    <label for="name"><?php echo e($productAttributes->attribute->name); ?></label>
                    <input class="form-control" name="Attribute_values[<?php echo e($productAttributes->id); ?>]" type="text" value="<?php echo e($productAttributes->value); ?>" >

                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </div>

               <?php $__currentLoopData = $productVariations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <div class="col-md-12">

                    <hr>

                    <div class="d-flex">

                        <p class="mb-0"> قیمت و موجودی برای متغیر (<?php echo e($variation->value); ?>) </p>

                        <p class="mb-0 mr-3">

                            <button class="btn btn-sm btn-primary" type="button" data-toggle="collapse" data-target="#collapse-<?php echo e($variation->id); ?>">

                                نمایش

                            </button>

                        </p>

                    </div>

               </div>

               <div class="col-md-12">

                    <div class="collapse mt-2" id="collapse-<?php echo e($variation->id); ?>">


                        <div class="card card-body">

                            <div class="row">


                                <div class="form-group col-md-3">

                                    <label for="name">قیمت</label>
                                    <input class="form-control" type="text" name="variation_values[<?php echo e($variation->id); ?>][price]" value="<?php echo e($variation->price); ?>" >

                                </div>

                                <div class="form-group col-md-3">s

                                    <label for="name">تعداد</label>
                                    <input class="form-control" name="variation_values[<?php echo e($variation->id); ?>][quantity]" type="text" value="<?php echo e($variation->quantity); ?>" >

                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">شناسه انبار</label>
                                    <input class="form-control" name="variation_values[<?php echo e($variation->id); ?>][sku]" type="text" value="<?php echo e($variation->sku); ?>" >

                                </div>

                                <div class="col-md-12">

                                    <hr>

                                    <p>حراجی</p>

                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">قیمت حراجی</label>
                                    <input class="form-control" name="variation_values[<?php echo e($variation->id); ?>][sale_price]" type="text" name="sale_price" value="<?php echo e($variation->sale_price); ?>" >

                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">تاریخ شروع تخفیف</label>

                                    <div class="input-group">

                                        <div class="input-group-prepend order-2">

                                            <span class="input-group-text" id="variationDateOnSaleFrom-<?php echo e($variation->id); ?>">

                                                <i class="fas fa-clock"></i>

                                            </span>

                                        </div>

                                        <input id="variationInputDateOnSaleFrom-<?php echo e($variation->id); ?>" class="form-control" name="variation_values[<?php echo e($variation->id); ?>][date_on_sale_from]" type="text" value="<?php echo e($variation->date_on_sale_from == null ? null:verta($variation->date_on_sale_from)); ?>" >

                                    </div>



                                </div>

                                <div class="form-group col-md-3">

                                    <label for="name">تاریخ پایان تخفیف</label>

                                    <div class="input-group">

                                        <div class="input-group-prepend order-2">

                                            <span class="input-group-text" id="variationDateOnSaleTo-<?php echo e($variation->id); ?>">

                                                <i class="fas fa-clock"></i>

                                            </span>

                                        </div>

                                        <input id="variationInputDateOnSaleTo-<?php echo e($variation->id); ?>" class="form-control" name="variation_values[<?php echo e($variation->id); ?>][date_on_sale_to]" type="text" value="<?php echo e($variation->date_on_sale_to == null ? null:verta($variation->date_on_sale_to)); ?>" >

                                    </div>



                                </div>


                            </div>

                        </div>

                    </div>

               </div>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <button type="submit" class="btn btn-outline-primary mt-5">ویرایش</button>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn mt-5 mr-3 btn-dark"> بازگشت </a>

               </div>

            </form>


        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>