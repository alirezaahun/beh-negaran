<?php $__env->startSection('scripts'); ?>
    <script>

            $('#attributeSelect').selectpicker({'title' : 'انتخاب ویژگی'});
            $('#tagSelect').selectpicker({'title' : 'انتخاب تگ'});

            $('#attributeSelect').on('changed.bs.select', function() {
            let attributesSelected = $(this).val();
            let attributes = <?php echo json_encode($attributes, 15, 512) ?>;

            let attributeForFilter = [];

            attributes.map((attribute) => {
                $.each(attributesSelected , function(i,element){
                    if( attribute.id == element ){
                        attributeForFilter.push(attribute);
                    }
                });
            });

            $("#attributeIsFilterSelect").find("option").remove();
            $("#variationSelect").find("option").remove();
            attributeForFilter.forEach((element)=>{
                let attributeFilterOption = $("<option/>" , {
                    value : element.id,
                    text : element.name
                });

                let variationOption = $("<option/>" , {
                    value : element.id,
                    text : element.name
                });

                $("#attributeIsFilterSelect").append(attributeFilterOption);
                $("#attributeIsFilterSelect").selectpicker('refresh');

                $("#variationSelect").append(variationOption);
                $("#variationSelect").selectpicker('refresh');
            });


        });

        $("#attributeIsFilterSelect").selectpicker({
            'title': 'انتخاب ویژگی'
        });

        $("#variationSelect").selectpicker({
            'title': 'انتخاب ویژگی'
        });



    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="mb-4">

            <h5 class="font-weight-bold">ایجاد دسته بندی</h5>

            <hr>

            <?php echo $__env->make('admin.sections.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

               <div class="form-row">

                <div class="form-group col-md-3">

                    <label for="name">نام</label>
                    <input class="form-control" type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">

                </div>

                <div class="form-group col-md-3">

                    <label for="slug">نام انگلیسی</label>
                    <input class="form-control" type="text" name="slug" id="slug" value="<?php echo e(old('slug')); ?>">

                </div>

                <div class="form-group col-md-3">

                    <label for="parent_id">والد</label>
                    <select class="form-control" name="parent_id" id="parent_id">

                        <option value="0" selected>بدون والد</option>
                        <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($parentCategory->id); ?>"><?php echo e($parentCategory->name); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>

                <div class="form-group col-md-3">

                    <label for="is_active">وضعیت</label>
                    <select class="form-control" name="is_active" id="is_active">

                        <option value="1" selected>فعال</option>
                        <option value="0">غیرفعال</option>

                    </select>

                </div>


                <div class="form-group col-md-3">

                    <label for="parent_id">ویژگی</label>
                    <select id="attributeSelect" data-live-search="true" name="attribute_ids[]" multiple class="form-control">

                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($attribute->id); ?>"><?php echo e($attribute->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>

                </div>

                <div class="form-group col-md-3">

                    <label for="parent_id">تگ</label>
                    <select id="tagSelect" data-live-search="true" name="tag_ids[]" multiple class="form-control">

                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>

                </div>

                

                <div class="form-group col-md-3">

                    <label for="name">آیکون</label>
                    <input class="form-control" type="text" name="icon" id="icon" value="<?php echo e(old('icon')); ?>">

                </div>

               </div>



            <div class="form-group col-md-12">

                <label for="name">توضیحات</label>
                <textarea class="form-control" type="text" name="description" id="description"><?php echo e(old('description')); ?></textarea>

            </div>

                <button type="submit" class="btn btn-outline-primary mt-5">ثبت</button>
                <a href="<?php echo e(route('admin.brands.index')); ?>" class="btn mt-5 mr-3 btn-dark"> بازگشت </a>

            </form>


        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\beh_negaran_eCommerce\eCommerce\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>