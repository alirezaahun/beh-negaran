    <!-- Icons On Mobile Scroll --------------------------------->

    <div class="container">
        <div class="row">

          <div class="service-icons-mobile d-sm-block d-md-none">
            <ul>
              <li> <a href="<?php echo e(route('home.services')); ?>/#video-service"><i class="fas fa-video"></i> </a> </li>
              <li> <a href="<?php echo e(route('home.services')); ?>/#photo-service"><i class="fas fa-camera"></i></a> </li>
              <li> <a href="<?php echo e(route('home.services')); ?>/#website-service"><i class="fas fa-laptop-code"></i> </a> </li>
              <li> <a href="<?php echo e(route('home.services')); ?>/#design-service"><i class="fas fa-palette"></i></a> </li>
              <li> <a href="<?php echo e(route('home.services')); ?>/#podcast-service"><i class="fas fa-microphone"></i></a> </li>
            </ul>
          </div>

        </div>
      </div>
<?php /**PATH E:\beh_negaran_eCommerce\eCommerce\resources\views/home/sections/iconsOnMobile.blade.php ENDPATH**/ ?>