<div id="myModal" class="modal">
    <!-- Modal content -->
    <div class="modal-content">
      <span class="close">&times;</span>
      <div class="container">
        <div class="form">

          </ul>

            <div id="login">
              <h3>خوش آمدید!</h3>

              <form id="loginForm">

                <div class="field-wrap">
                <label>
                </label>
                <input id="phoneInput" placeholder="شماره همراه خود را وارد کنید" type="text"required autocomplete="off"/>
                <button type="submit">ورود</button>

            </div>



              </form>

            </div>

          </div><!-- tab-content -->

    </div> <!-- /form -->
      </div>

    </div>

  </div>

  <?php $__env->startSection('js'); ?>

<script>

  $('#loginForm').submit(function(event){

      console.log($('#phoneInput').val());
      event.preventDefault();

  });

</script>

<?php $__env->stopSection(); ?>

<?php /**PATH E:\beh_negaran_eCommerce\eCommerce\resources\views/home/sections/modal.blade.php ENDPATH**/ ?>