<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="d-flex justify-content-between mb-4">

            <h5 class="font-weight-bold">لیست بنر ها (<?php echo e($banner->total()); ?>)</h5>

            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.banners.create')); ?>">

                <li class="fa fa-plus"></li>

                ایجاد بنر

            </a>


        </div>

        <table class="table table-bordered table-striped text-center">

            <thead>

                <tr>

                    <th>
                        #
                    </th>
                    <th>
                        تصویر
                    </th>
                    <th>
                        عنوان
                    </th>
                    <th>
                        متن
                    </th>
                    <th>
                        اولویت
                    </th>
                    <th>
                        وضعیت
                    </th>
                    <th>
                        نوع
                    </th>
                    <th>
                        متن دکمه
                    </th>
                    <th>
                        لینک دکمه
                    </th>
                    <th>
                        آیکون دکمه
                    </th>
                    <th>
                        عملیات
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banners): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th>
                    <?php echo e($banner->firstItem() + $key); ?>

                    </th>

                    <th>
                       <a target="_blank" href="<?php echo e(url(env('BANNER_IMAGE_UPLOAD_PATH').$banners->image)); ?>"><?php echo e($banners->image); ?></a>
                    </th>

                    <th>
                        <?php echo e($banners->title); ?>

                     </th>

                     <th>
                        <?php echo e($banners->text); ?>

                     </th>
                     <th>
                        <?php echo e($banners->priority); ?>

                     </th>

                     <th>
                        <span class="<?php echo e($banners->getRawOriginal('is_active') ? 'text-success' : 'text-danger'); ?>"><?php echo e($banners->is_active); ?></span>
                     </th>
                     <th>
                        <?php echo e($banners->type); ?>

                     </th>
                     <th>
                        <?php echo e($banners->button_text); ?>

                     </th>
                     <th>
                        <?php echo e($banners->button_link); ?>

                     </th>
                     <th>
                        <?php echo e($banners->button_icon); ?>

                     </th>


                    <th>
                        <a href="<?php echo e(route('admin.banners.edit' , ['banner' => $banners->id])); ?>" class="btn btn-outline-info">ویرایش</a>

                        <form action="<?php echo e(route('admin.banners.destroy', ['banner'=>$banners->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-outline-danger" type="submit">حذف</button>

                    </form>
                    </th>

                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/banners/index.blade.php ENDPATH**/ ?>