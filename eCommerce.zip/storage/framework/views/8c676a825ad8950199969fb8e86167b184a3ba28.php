  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/sections/scroll_top.blade.php ENDPATH**/ ?>