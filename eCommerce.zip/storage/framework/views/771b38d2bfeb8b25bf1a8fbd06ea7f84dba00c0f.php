<footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>!Hello World</span>
      </div>
    </div>
  </footer>
<?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/sections/footer.blade.php ENDPATH**/ ?>