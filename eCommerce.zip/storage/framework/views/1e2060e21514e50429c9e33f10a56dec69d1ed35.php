<?php $__env->startSection('scripts'); ?>

<script>

$("#primary_image").change(function(){

var filename = $(this).val();
$(this).next('.custom-file-label').html(filename);

});


$("#images").change(function(){

var filename = $(this).val();
$(this).next('.custom-file-label').html(filename);

});

</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="mb-4">

            <h5 class="font-weight-bold">ویرایش تصویر:<?php echo e($product->name); ?></h5>

            <hr>

            <?php echo $__env->make('admin.sections.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row">

                <div class="col-md-12">
                    <h5>تصویر اصلی</h5>
                </div>

                <div class="col-md-3">

                    <div class="card">
                        <img src="<?php echo e(url(env('PRODUCT_IMAGE_UPLOAD_PATH') . $product->primary_image)); ?>" alt="<?php echo e($product->name); ?>" class="card-img-top">
                    </div>

                </div>

            </div>

            <hr>

            <div class="row">


                <div class="col-md-12">
                    <h5>تصاویر</h5>
                </div>

                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                   <div class="col-md-3">

                        <div class="card">

                            <img src="<?php echo e(url(env('PRODUCT_IMAGE_UPLOAD_PATH') . $image->image)); ?>" alt="<?php echo e($product->name); ?>" class="card-img-top">


                            <div class="card-body text-center">

                                <form action="<?php echo e(route('admin.product.image.destroy' , ['product' => $product->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <input type="hidden" name="image_id" value="<?php echo e($image->id); ?>">
                                    <button type="submit" class="btn btn-danger mb-5">حذف</button>

                                </form>

                                <form action="<?php echo e(route('admin.product.image.setPrimary', ['product' => $product->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <input type="hidden" name="image_id" value="<?php echo e($image->id); ?>">
                                    <button type="submit" class="btn btn-primary">انتخاب به عنوان تصویر اصلی</button>

                                </form>

                            </div>

                        </div>

                   </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <hr>

                <form action="<?php echo e(route('admin.product.image.add' , ['product' => $product->id])); ?>" method="POST" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-md-4">

                            <label for="primary-image">انتخاب تصویر اصلی</label>

                            <div class="custom-file">

                                <input type="file" name="primary_image" class="custom-file-input" id="primary_image">
                                <label for="primay_image" class="custom-file-label">انتخاب فایل</label>

                            </div>

                        </div>

                        <div class="form-group col-md-4">

                            <label for="primary-image">سایر تصاویر</label>

                            <div class="custom-file">

                                <input type="file" name="images[]" multiple class="custom-file-input" id="images">
                                <label for="images" class="custom-file-label">انتخاب فایل</label>

                            </div>
                        </div>

                    </div>


                    <button type="submit" class="btn btn-outline-primary mt-5">ویرایش</button>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn mt-5 mr-3 btn-dark"> بازگشت </a>
                </form>

    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pi4001027\eCommerce\resources\views/admin/products/edit_image.blade.php ENDPATH**/ ?>