<!-- Mobile Bottom Navbar --------------------------------------------->
<nav id="navContainer" class="nav">
    <a href="<?php echo e(route('home.index')); ?>" class="nav__link ---active">
      <i class='bx bx-home nav__icon'></i>
      <span class="nav__text">خانه</span>
    </a>
    <a href="#" class="nav__link">
      <i class='bx bx-shopping-bag nav__icon'></i>
      <span class="nav__text">سفارش ها</span>
    </a>
    <a href="#" class="nav__link">
      <i class='bx bx-user nav__icon'></i>
      <span class="nav__text">حساب من</span>
    </a>

  </nav>
<?php /**PATH E:\beh_negaran_eCommerce\eCommerce\resources\views/home/sections/mobileNavbar.blade.php ENDPATH**/ ?>